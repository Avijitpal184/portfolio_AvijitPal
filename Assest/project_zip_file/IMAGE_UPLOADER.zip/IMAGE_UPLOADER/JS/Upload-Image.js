var picobject;

function chooseFile() {
    if (imgbox.innerHTML.includes("<img src=") ) {
        alert("Only 1 Image allowed.");
        return true;
    }
    file1.click();
}

function prevewImage(input) {

        var file1 = document.getElementById('file1');
        var fileSize = file1.files[0].size;
        var maxSize = 2000000 // 2MB

        picobject = input.files[0];

    if (fileSize < maxSize) {
            var preview = document.createElement('img');
            preview.src = URL.createObjectURL(picobject);
            imgbox.append(preview);
            uploadbtn.style.display = "block";
            gap.style.display = "block";
    }else{
        alert('Image size must be less than 2MB');
    }
        
        // var preview = document.createElement('img');
        // preview.src = URL.createObjectURL(picobject);
        // imgbox.append(preview);
        // uploadbtn.style.display = "block"
        // gap.style.display = "block"
}

function upload() {
    alert("Ajax will Upload "+picobject+" now.")
}