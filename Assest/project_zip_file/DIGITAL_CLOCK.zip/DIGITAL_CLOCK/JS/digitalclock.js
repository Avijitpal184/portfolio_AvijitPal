let hrs = document.getElementById("hrs");
let min = document.getElementById("min");
let sec = document.getElementById("sec");
let ampm = document.getElementById("amandpm");

// setInterval(function(){
//     let currentTime = new Date();

//     let hours = currentTime.getHours(); // hours start
//     let ampm = hours >= 12 ? 'PM' : 'AM';
//     hours = hours % 12;
//     hours = hours? hours: 12;
//     hrs.innerHTML = (hours < 10 ? "0" : "") + hours; // hours end

//     min.innerHTML = (currentTime.getMinutes() < 10 ? "0" : "") + currentTime.getMinutes();
//     sec.innerHTML = (currentTime.getSeconds() < 10 ? "0" : "") + currentTime.getSeconds();
//     amandpm.innerHTML = ampm;
// }, 1000);

function timeUpdate() {
    let currentTime = new Date();
    let hours = currentTime.getHours();
    let ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours || 12;
    hrs.innerHTML = (hours < 10 ? "0" : "") + hours;
    min.innerHTML = (currentTime.getMinutes() < 10 ? "0" : "") + currentTime.getMinutes();
    sec.innerHTML = (currentTime.getSeconds() < 10 ? "0" : "") + currentTime.getSeconds();
}

setInterval(timeUpdate, 1000);



