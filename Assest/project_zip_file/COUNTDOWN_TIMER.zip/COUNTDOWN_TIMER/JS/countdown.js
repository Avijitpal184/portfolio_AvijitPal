


var endDate = setInterval(function(){

    var countDownDays = new Date("August 15, 2024 12:00:00").getTime();
    var now = new Date().getTime();
    var distance = countDownDays - now;

    // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    // var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    // var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    // var seconds = Math.floor((distance % (1000 * 60)) / 1000);

    var seconds = Math.floor(distance / 1000);
    var minutes = Math.floor(seconds / 60);
    var hours = Math.floor(minutes / 60);
    var days = Math.floor(hours / 24);

    hours %= 24;
    minutes %= 60;
    seconds %= 60;

    document.getElementById("daysBox").innerHTML = days;
    document.getElementById("hoursBox").innerHTML = hours;
    document.getElementById("minsBox").innerHTML = minutes;
    document.getElementById("secsBox").innerHTML = seconds;

    if(distance < 0) {
        clearInterval(endDate);
        document.getElementById("Maintenance").style.display = "none"
        document.getElementById("Launch").innerHTML = "Now You Can Visit Our Website.";
        document.getElementById("Launch").style.color = "#029eff";
        document.getElementById("daysBox").innerHTML = "00";
        document.getElementById("hoursBox").innerHTML = "00";
        document.getElementById("minsBox").innerHTML = "00";
        document.getElementById("secsBox").innerHTML = "00";
    }
},1000);










































// function endDate() {
//     var xmas = new Date("November 6, 2023 10:19:00");
//     var now = new Date();
//     var timeEnd = xmas.getTime() - now.getTime();

    

//     if(timeEnd < 0) {
//         clearTimeout(timer);
//         document.getElementById("Launch").innerHTML = "ajhsdjafl";

//         document.getElementById("daysBox").innerHTML = "00";
//         document.getElementById("hoursBox").innerHTML = "00";
//         document.getElementById("minsBox").innerHTML = "00";
//         document.getElementById("secsBox").innerHTML = "00";
//     } else if (timeEnd < 0) {
//         clearTimeout(timer);
//         return;
//     }
//     //     clearTimeout(timer);
//     //     document.getElementById("Launch").innerHTML = "ajhsdjafl";

//     //     document.getElementById("daysBox").innerHTML = "00";
//     //     document.getElementById("hoursBox").innerHTML = "00";
//     //     document.getElementById("minsBox").innerHTML = "00";
//     //     document.getElementById("secsBox").innerHTML = "00";
//     // }
//     // var days = Math.floor(timeEnd / (1000 * 60 * 60 * 24));
//     // var hours = Math.floor((timeEnd % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
//     // var minutes = Math.floor((timeEnd % (1000 * 60 * 60)) / (1000 * 60));
//     // var seconds = Math.floor((timeEnd % (1000 * 60)) / 1000);

//     var seconds = Math.floor(timeEnd / 1000);
//     var minutes = Math.floor(seconds / 60);
//     var hours = Math.floor(minutes / 60);
//     var days = Math.floor(hours / 24);

//     hours %= 24;
//     minutes %= 60;
//     seconds %= 60;

//     document.getElementById("daysBox").innerHTML = days;
//     document.getElementById("hoursBox").innerHTML = hours;
//     document.getElementById("minsBox").innerHTML = minutes;
//     document.getElementById("secsBox").innerHTML = seconds;
//     var timer = setTimeout('endDate()', 1000);
// }
// endDate();























