// When typing the password, the eye icon is shown or hidden.
function toggleEye() {
    var passwordInput = document.getElementById('password');
    var eyeIcon = document.getElementById('eye');
    if (passwordInput.value !== '') {
        eyeIcon.style.visibility = 'visible';
    } else {
        eyeIcon.style.visibility = 'hidden';
    }
}


// Password show hide button.
function showHide() {
    var passwordInput = document.getElementById('password');
    var eyeIcon = document.getElementById('eye');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.style.backgroundImage = "url('images/pass-show.png')";
    } else {
        passwordInput.type = 'password';
        eyeIcon.style.backgroundImage = "url('images/pass-hide.png')";
    }
}
