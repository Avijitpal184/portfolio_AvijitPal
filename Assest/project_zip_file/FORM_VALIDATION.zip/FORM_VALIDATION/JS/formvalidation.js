//         Java Script Form Validation 

var form = document.getElementById('form');
var fname = document.getElementById('fname');
var username = document.getElementById('username');
var email = document.getElementById('email');
var phonenumber = document.getElementById('phonenumber');
var pass = document.getElementById('pass');
var cpass = document.getElementById('cpass');
var gender = document.getElementsByName('gender'); // Assuming 'gender' is the name of radio button group



form.addEventListener('submit', function(event){
    event.preventDefault();
    
    validate();
})

function validate() {
    var fnameVal = fname.value.trim();
    var usernameVal = username.value.trim();
    var emailVal = email.value.trim();
    var phonenumberVal = phonenumber.value.trim();
    var passwordVal = pass.value.trim();
    var cpasswordVal = cpass.value.trim();

   


    // validate name
    if (fnameVal === "") {
        setErroMsg(fname, 'Name cannot be empty');
    } else if (fnameVal.length <= 2) {
        setErroMsg(fname, 'Name should be at least 3 characters');
    } else {
        setSuccessMsg(fname);
    }

    // validate username
    if (usernameVal === "") {
        setErroMsg(username, 'Username cannot be empty');
    } else if (usernameVal.length <= 2) {
        setErroMsg(username, 'Username should be at least 3 characters');
    } else {
        setSuccessMsg(username);
    }

    // validate email 
    if (emailVal == "") {
        setErroMsg(email, 'Email cannot be empty');
    } else {
        setSuccessMsg(email);
    }

    // validate phonenumber
    if (phonenumberVal === "") {
        setErroMsg(phonenumber, 'Phone number cannot be empty');
    } else if (phonenumberVal.length != 10) {
        setErroMsg(phonenumber, 'Invalid phone number');
    } else {
        setSuccessMsg(phonenumber);
    }
    

    // validate Password
    if (passwordVal === "") {
        setErroMsg(pass, 'Please create a password');
    } else if (passwordVal.length <= 5) {
        setErroMsg(pass, 'Password should be at least 6 characters');
    } else {
        setSuccessMsg(pass);
    }

    // validate Password
    if (cpasswordVal === "") {
        setErroMsg(cpass, 'Confirm password cannot be empty');
    } else if (passwordVal !== cpasswordVal) {
        setErroMsg(cpass, 'Passwords do not match');
    } else {
        setSuccessMsg(cpass);
    }

    // validate gender
    var genderSelected = false;
    for (var i = 0; i < gender.length; i++) {
        if (gender[i].checked) {
            genderSelected = true;
            break;
        }
    }
    
    if(!genderSelected) {
        setErroMsg(gender[0], 'Please select your gender');
    } else {
        setSuccessMsg(gender[0]);
    }
}




function setErroMsg(input, errormsgs) {
    var formControl = input.parentElement;
    var small = formControl.querySelector('small');
    formControl.className = "form-control error"
    small.innerText = errormsgs;
}

function setSuccessMsg(input) {
    var formControl = input.parentElement;
    formControl.className = "form-control success"
}





