let timeerInterval;
let hours = 0;
let minutes = 0;
let seconds = 0;

var hoursDisplay = document.getElementById('hrs');
var minutesDisplay = document.getElementById('min');
var secondsDisplay = document.getElementById('sec');

function startStop(){
    if (startStopBtn.querySelector('i').classList.contains('bi-play-fill')){
        startStopBtn.innerHTML = '<i class="bi bi-pause-fill"></i>';
        timeerInterval = setInterval(updateTimer, 1000);
    } else {
        startStopBtn.innerHTML = '<i class="bi bi-play-fill"></i>';
        clearInterval(timeerInterval);
    }
}

function reset() {
    clearInterval(timeerInterval);
    startStopBtn.innerHTML = '<i class="bi bi-play-fill"></i>';
    hours = minutes = seconds = 0;
    updateDisplay();
}

function updateTimer() {
    seconds++;
    if (seconds === 60) {
        seconds = 0;
        minutes++;
    }
    if (minutes === 60) {
        minutes = 0;
        hours++;
    }
    updateDisplay();
}

function updateDisplay() {
    hoursDisplay.textContent = formatTime(hours);
    minutesDisplay.textContent = formatTime(minutes);
    secondsDisplay.textContent = formatTime(seconds);
}

function formatTime(time) {
    return time < 10 ? '0' + time : time;
}



